export const config = {
     apiUrl: 'https://localhost:7184/api'
};