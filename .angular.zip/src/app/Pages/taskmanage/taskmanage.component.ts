import { Component } from '@angular/core';

@Component({
  selector: 'app-taskmanage',
  templateUrl: './taskmanage.component.html',
  styleUrl: './taskmanage.component.css'
})
export class TaskmanageComponent {

  tasks: any[] = [];
  
}
