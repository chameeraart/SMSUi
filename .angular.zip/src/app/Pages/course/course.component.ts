import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TaskService } from '../../Services/task.service';
import { HttpErrorResponse } from '@angular/common/http';
import { CourseService } from '../../Services/course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrl: './course.component.css'
})
export class CourseComponent {
  
  submitted = false;
  loading = false;
  error = '';
  Courses: any[] = [];
  editCourse: any = null;
  searchTerm: string = '';
  sortBy: string = '';
  sortDirection: number = 1;
  pageSize: number = 5; // Number of items per page
  currentPage: number = 1; // Current page number
  // Define task as a FormGroup
  Course: FormGroup;

  constructor(private fb: FormBuilder, private api: CourseService, private tostr: ToastrService) { }

  ngOnInit() {
    // Initialize the form group with form controls
    this.initFormgroup();
    this.GetCourses();
  }



  initFormgroup() {
    this.Course = this.fb.group({
      Id: [0],
      Title: ['', Validators.required],
      Description: ['', Validators.required],
      StartDate: ['', Validators.required],
      EndDate: ['', Validators.required],
      Instructor: ['', Validators.required],
      Language: ['', Validators.required],
      Created_datetime: [''],
      Fee: ['', Validators.required],
      Status: ['']
    });
  }

  GetCourses() {
    this.loading = true;
    this.api.getsaveGetAllCourse().subscribe(result => {
      this.Courses = Object.assign([], result);
      this.loading = false;
    });
  }

  LoadData() {
    this.Course = this.fb.group({
      Id: [this.editCourse.id],
      Title: [this.editCourse.title],
      Description: [this.editCourse.description],
      StartDate: [this.convertToDate(this.editCourse.startDate)],
      EndDate: [this.convertToDate(this.editCourse.endDate)],
      Instructor: [this.convertToDate(this.editCourse.instructor)],
      Language: [this.convertToDate(this.editCourse.language)],
      Created_datetime: [this.convertToDate(this.editCourse.created_datetime)],
      Fee: [this.convertToDate(this.editCourse.fee)],
      Status: [this.convertToDate(this.editCourse.status)]
      
      
    });
  }

  convertToDate(dateString: string): string {
    // Assuming dateString is in the format "yyyy-MM-ddTHH:mm:ss"
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // Convert date to "yyyy-MM-dd" format
  }

  // Save The Course
  submitForm() {
    this.submitted = true;
    // Check if the form is invalid
    if (this.Course.invalid) {
      this.tostr.error('Please fill out all fields.');
      return;
    }

    this.loading = true; // Set loading to true before making the API call
    this.api.saveCourse(this.Course.value).subscribe(
      result => {
        this.tostr.success("Course Details Saved Successfully");
        this.loading = false;
        this.Course.reset(); // Reset the form after successful submission
        this.GetCourses();
        this.initFormgroup();
      },
      (error: HttpErrorResponse) => {
        this.tostr.error("An error occurred while saving Course details");
        this.loading = false;
        console.error(error);
      }
    );
  }

  // Edit Selected Record
  onEdit(id: number) {
    this.loading = true;
    this.api.getSCourse(id).subscribe(result => {
      this.editCourse = Object.assign([], result);
      this.LoadData();
      this.loading = false;
    });
  }

  // Delete the Selected Record
  onDelete(id: number) {
    if (confirm('Are You Sure To Delete This Record?')) {
      this.api.deleCourse(id).subscribe(
        result => {
          this.tostr.success("Delete Course Successfully");
          this.GetCourses();
        },
        (error: HttpErrorResponse) => {
          this.loading = false;
        }
      );
    }
  }



  // Reset the form
  clear() {
    this.Course.reset(); // Reset the form
  }



}
