import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EnrollService } from '../../Services/enroll.service';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-enroll',
  templateUrl: './enroll.component.html',
  styleUrl: './enroll.component.css'
})
export class EnrollComponent {
  submitted = false;
  loading = false;
  error = '';
  Courses: any[] = [];
  editEnroll: any = null;
  searchTerm: string = '';
  sortBy: string = '';
  sortDirection: number = 1;
  pageSize: number = 5; // Number of items per page
  currentPage: number = 1; // Current page number
  // Define task as a FormGroup
  Enroll: FormGroup;

  constructor(private fb: FormBuilder, private api: EnrollService, private tostr: ToastrService) { }

  ngOnInit() {
    // Initialize the form group with form controls
    this.initFormgroup();
    this.GetCourses();
  }


  initFormgroup() {
    this.Enroll = this.fb.group({
      Id: [0],
      Student_Id: ['', Validators.required],
      Course_Id: ['', Validators.required],
      Created_datetime: [''],
      Status: ['']
    });
  }

  GetCourses() {
    this.loading = true;
    this.api.getEnrolAll().subscribe(result => {
      this.Courses = Object.assign([], result);
      this.loading = false;
    });
  }

  LoadData() {
    this.Enroll = this.fb.group({
      Id: [this.editEnroll.id],
      Student_Id: [this.editEnroll.student_Id],
      Course_Id: [this.editEnroll.description],
      Created_datetime: [this.convertToDate(this.editEnroll.created_datetime)],
      Status: [this.convertToDate(this.editEnroll.status)]
      
      
    });
  }

  convertToDate(dateString: string): string {
    // Assuming dateString is in the format "yyyy-MM-ddTHH:mm:ss"
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // Convert date to "yyyy-MM-dd" format
  }

  // Save The Enroll
  submitForm() {
    this.submitted = true;
    // Check if the form is invalid
    if (this.Enroll.invalid) {
      this.tostr.error('Please fill out all fields.');
      return;
    }

    this.loading = true; // Set loading to true before making the API call
    this.api.saveEnroll(this.Enroll.value).subscribe(
      result => {
        this.tostr.success("Enroll Details Saved Successfully");
        this.loading = false;
        this.Enroll.reset(); // Reset the form after successful submission
        this.GetCourses();
        this.initFormgroup();
      },
      (error: HttpErrorResponse) => {
        this.tostr.error("An error occurred while saving Course details");
        this.loading = false;
        console.error(error);
      }
    );
  }

  // Edit Selected Record
  onEdit(id: number) {
    this.loading = true;
    this.api.getEnroll(id).subscribe(result => {
      this.editEnroll = Object.assign([], result);
      this.LoadData();
      this.loading = false;
    });
  }

  // Delete the Selected Record
  onDelete(id: number) {
    if (confirm('Are You Sure To Delete This Record?')) {
      this.api.deleEnroll(id).subscribe(
        result => {
          this.tostr.success("Delete Enroll Successfully");
          this.GetCourses();
        },
        (error: HttpErrorResponse) => {
          this.loading = false;
        }
      );
    }
  }

  // Reset the form
  clear() {
    this.Enroll.reset(); // Reset the form
  }

}
