import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../../Services/task.service';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { StudentregisterService } from '../../Services/studentregister.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-register',
  templateUrl: './student-register.component.html',
  styleUrl: './student-register.component.css'
})
export class StudentRegisterComponent {
  submitted = false;
  loading = false;
  error = '';
  Student: FormGroup;

  constructor(private fb: FormBuilder, private api: StudentregisterService, private tostr: ToastrService,    private router: Router) { }

  ngOnInit() {
    // Initialize the form group with form controls
    this.initFormgroup();
  }

  initFormgroup() {
    this.Student = this.fb.group({
      Id: [0],
      Name: ['', Validators.required],
      Email: ['', Validators.required],
      Phone: ['', Validators.required],
      Sex: ['', Validators.required],
      IdNumber: ['', Validators.required],
      Password: ['', Validators.required],
      Birthday: ['', Validators.required],
      Status: [true]
    });
  }

  convertToDate(dateString: string): string {
    // Assuming dateString is in the format "yyyy-MM-ddTHH:mm:ss"
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // Convert date to "yyyy-MM-dd" format
  }

  // Save The Task
  submitForm() {

    console.log(this.Student.value)
    this.submitted = true;
    // Check if the form is invalid
    if (this.Student.invalid) {
      this.tostr.error('Please fill out all fields.');
      return;
    }

    this.loading = true; // Set loading to true before making the API call
    this.api.saveStudent(this.Student.value).subscribe(
      result => {
        this.tostr.success("Student Create Successfully");
        this.loading = false;
        this.Student.reset(); // Reset the form after successful submission
        this.initFormgroup();
        this.router.navigate(['/login']);
      },
      (error: HttpErrorResponse) => {
        this.tostr.error("An error occurred while saving Student details");
        this.loading = false;
        console.error(error);
      }
    );
  }



}
